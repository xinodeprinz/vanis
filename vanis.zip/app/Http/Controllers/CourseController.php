<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\RegisteredCourses;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CourseController extends Controller
{
    public function __construct()
    {
        return $this->middleware('auth');
    }

    public function index(Request $request, $type)
    {
        if (!in_array(strtolower($type), ['major', 'minor', 'elective', 'required'])) {
            return abort(404);
        }
        $semester = env('SEMESTER');
        $academic_year = env('ACADEMIC_YEAR');

        $added_courses = $request->session()->has('courses') ? $request->session()->get('courses') : [];
        $courses_yoo_obj = Course::where('type', $type)->get();
        $registered_courses = RegisteredCourses::where('semester', $semester)
            ->where('academic_year', $academic_year)
            ->get();
        $courses = [];
        foreach ($courses_yoo_obj as $rt) {
            $courses[] = $rt;
        }

        if ($registered_courses) {
            foreach ($courses as $c) {
                foreach ($registered_courses as $r) {
                    if ($c->course_code === $r->course_code && $r->semester === $semester && $r->academic_year === $academic_year) {
                        $index = array_search($c, $courses);
                        unset($courses[$index]);
                    }
                }
            }
        } else {
            $courses = $courses_yoo_obj;
        }

        $c_num = 0;
        $c_credit = 0;
        if ($request->session()->has('courses')) {
            $s_ids = $request->session()->get('courses');
            $c_num = count($s_ids);

            foreach ($s_ids as $i) {
                $c_yoo = Course::find($i);
                $c_credit += $c_yoo->credit_value;
            }
        }
        return view('course-registration', compact('courses', 'added_courses', 'registered_courses', 'c_num', 'c_credit'));
    }

    public function register(Request $request)
    {
        $course_ids = $request->session()->get('courses');
        if (empty($course_ids)) {
            return back()->withErrors(['reg_error' => 'No course added for registration.']);
        }

        $semester = env('SEMESTER');
        $academic_year = env('ACADEMIC_YEAR');

        foreach ($course_ids as $id) {
            $course = Course::find($id);
            RegisteredCourses::create([
                'course_code' => $course->course_code,
                'course_title' => $course->course_title,
                'credit_value' => $course->credit_value,
                'type' => $course->type,
                'user_id' => Auth::id(),
                'semester' => $semester,
                'academic_year' => $academic_year,
            ]);
        }

        $request->session()->forget('courses');

        return back()->with('success', 'Courses registered successfully.');
    }

    public function addCourse(Request $request)
    {
        $course_id = $request->course_id;
        $courses = $request->session()->has('courses') ? $request->session()->get('courses') : [];

        if (!in_array($course_id, $courses)) {
            $request->session()->push('courses', $course_id);
        } else {
            $index = array_search($course_id, $courses);
            unset($courses[$index]);
            $request->session()->put('courses', $courses);
        }

        return back();
    }

    public function dropCourse(Request $request)
    {
        $course_id = $request->course_id;
        $course = RegisteredCourses::find($course_id);
        $course->delete();
        return back()->with('success', 'Course dropped successfully.');
    }
}