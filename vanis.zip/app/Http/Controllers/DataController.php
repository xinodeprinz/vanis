<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;

class DataController extends Controller
{
    public function storeCourses()
    {
        $courses = [
            ['course_code' => 'XAF201', 'course_title' => 'Pulic Finance', 'credit_value' => 4, 'type' => 'major'],
            ['course_code' => 'XAF212', 'course_title' => 'Cameroon History', 'credit_value' => 6, 'type' => 'major'],
            ['course_code' => 'XAF254', 'course_title' => 'World History', 'credit_value' => 5, 'type' => 'major'],
            ['course_code' => 'XAF276', 'course_title' => 'Africa History', 'credit_value' => 4, 'type' => 'major'],

            ['course_code' => 'XAF253', 'course_title' => 'Microbiology', 'credit_value' => 4, 'type' => 'minor'],
            ['course_code' => 'XAF278', 'course_title' => 'Biochemistry I', 'credit_value' => 6, 'type' => 'minor'],
            ['course_code' => 'XAF267', 'course_title' => 'Basics of computing', 'credit_value' => 5, 'type' => 'minor'],
            ['course_code' => 'XAF270', 'course_title' => 'Food science', 'credit_value' => 4, 'type' => 'minor'],

            ['course_code' => 'XAF263', 'course_title' => 'Mathematics', 'credit_value' => 4, 'type' => 'elective'],
            ['course_code' => 'XAF218', 'course_title' => 'Accounting', 'credit_value' => 6, 'type' => 'elective'],
            ['course_code' => 'XAF287', 'course_title' => 'English', 'credit_value' => 5, 'type' => 'elective'],
            ['course_code' => 'XAF240', 'course_title' => 'Civics and Ethics', 'credit_value' => 4, 'type' => 'elective'],

            ['course_code' => 'XAF273', 'course_title' => 'Physics I', 'credit_value' => 4, 'type' => 'required'],
            ['course_code' => 'XAF258', 'course_title' => 'Marketing', 'credit_value' => 6, 'type' => 'required'],
            ['course_code' => 'XAF207', 'course_title' => 'Management', 'credit_value' => 5, 'type' => 'required'],
            ['course_code' => 'XAF220', 'course_title' => 'Citizenship', 'credit_value' => 4, 'type' => 'required'],
        ];

        foreach ($courses as $course) {
            Course::create($course);
        }

        return 1;
    }
}