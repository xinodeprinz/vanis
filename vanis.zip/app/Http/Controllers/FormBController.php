<?php

namespace App\Http\Controllers;

use App\Models\RegisteredCourses;
use Illuminate\Http\Request;

class FormBController extends Controller
{
    public function __construct()
    {
        return $this->middleware('auth');
    }

    public function index()
    {
        $semester = env('SEMESTER');
        $academic_year = env('ACADEMIC_YEAR');

        $credits = 0;

        $courses = RegisteredCourses::where('semester', $semester)
            ->where('academic_year', $academic_year)
            ->get();

        foreach ($courses as $course) {
            $credits += $course->credit_value;
        }

        return view('form-b', compact('courses', 'credits'));
    }
}