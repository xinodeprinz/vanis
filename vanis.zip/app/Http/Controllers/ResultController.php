<?php

namespace App\Http\Controllers;

use App\Models\RegisteredCourses;
use Illuminate\Http\Request;

class ResultController extends Controller
{
    public function __construct()
    {
        return $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $semester = $request->semester ?? env('SEMESTER');
        $academic_year = $request->academic_year ?? env('ACADEMIC_YEAR');

        $courses = RegisteredCourses::where('semester', $semester)
            ->where('academic_year', $academic_year)
            ->where('exam_mark', '!=', null)
            ->get();

        if (!empty($courses)) {
            $totalCredit = $credit_earned = $totalGP_and_CV = $subjects_passed = 0;
            for ($i = 0; $i < count($courses); $i++) {
                $courses[$i]->ca_mark = $courses[$i]->ca_mark == null ? 0 : $courses[$i]->ca_mark;
                $courses[$i]->exam_mark = $courses[$i]->exam_mark == null ? 0 : $courses[$i]->exam_mark;
                $total_mark = $courses[$i]->ca_mark + $courses[$i]->exam_mark;
                $courses[$i]->total_mark = $total_mark;
                $courses[$i]->grade = $this::grade($total_mark)[0];
                $totalGP_and_CV += ($this::grade($total_mark)[1] * $courses[$i]->credit_value);
                $totalCredit += $courses[$i]->credit_value;
                $credit_earned += ($this::grade($total_mark)[1] > 1.5) ? $courses[$i]->credit_value : 0;
                $subjects_passed += ($this::grade($total_mark)[1] > 1.5) ? 1 : 0;
            }
            $gpa = $totalCredit > 0 ? number_format($totalGP_and_CV / $totalCredit, 2) : null;
        }
        $years = self::years_semesters()[0];
        $semesters = self::years_semesters()[1];
        return view('result', compact('courses', 'totalCredit', 'credit_earned', 'gpa', 'years', 'semesters'));
    }

    private static function grade($mark)
    {
        if ($mark < 45) {
            return ['F', 0];
        } else if ($mark < 45) {
            return ['D', 1];
        } else if ($mark < 50) {
            return ['D+', 1.5];
        } else if ($mark < 55) {
            return ['C', 2];
        } else if ($mark < 60) {
            return ['C+', 2.5];
        } else if ($mark < 70) {
            return ['B', 3];
        } else if ($mark < 80) {
            return ['B+', 3.5];
        } else {
            return ['A', 4];
        }
    }

    private static function years_semesters()
    {
        return [
            [
                '2020/2021',
                '2021/2022',
                '2022/2023',
                '2023/2024',
                '2024/2025',
                '2025/2026',
            ],
            [
                'first semester',
                'first semester resit',
                'seconde semester',
                'seconde semester resit',
            ]
        ];
    }
}