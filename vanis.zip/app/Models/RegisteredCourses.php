<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RegisteredCourses extends Model
{
    use HasFactory;

    protected $fillable = [
        'course_code',
        'course_title',
        'credit_value',
        'type',
        'user_id',
        'semester',
        'academic_year',
        'ca_mark',
        'exam_mark',
    ];
}