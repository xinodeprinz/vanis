<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login</title>
  <link rel="stylesheet" href="/css/bootstrap.css" />
  <link rel="stylesheet" href="/css/style.css" />
</head>

<body class="center bg-primary">

      <?php echo $__env->yieldContent('content'); ?>

    <script src="/js/bootstrap.bundle.min.js"></script>
    <script src="/js/all.js"></script>
</body>

</html><?php /**PATH C:\Users\NdeTek\Desktop\Vanis - Design\vanis - laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>