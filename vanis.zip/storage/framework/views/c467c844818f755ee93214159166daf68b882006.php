


<?php $__env->startSection('content'); ?>

<div class="container w-75 mt-5 text-white text-capitalize fs-vanis fw-bold">
    <form method="post" action="<?php echo e(route('get-result')); ?>">
        <?php echo csrf_field(); ?>
        <div class="d-flex justify-content-between align-items-end">
                <div class="mb-3">
                    <label for="academic_year" class="form-label">Select academic year</label>
                    <select class="form-select" name="academic_year" id="academic_year" style="width: 250px;">
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($year); ?>" @selected($year == env('ACADEMIC_YEAR'))><?php echo e($year); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="semester" class="form-label">Select semester</label>
                    <select class="form-select text-capitalize" name="semester" id="semester"  style="width: 250px;">
                        <?php $__currentLoopData = $semesters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sem); ?>" @selected($sem == env('SEMESTER'))><?php echo e($sem); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-success">Get Results</button>
                </div>
        </div>
    </form>
</div>

<div class="center bg-primary" style="margin-top: -200px;">
    <div class="card w-75">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-condensed">
                    <thead class="text-primary text-center">
                        <tr class="fs-vanis">
                            <th>SN</th>
                            <th>Course Code</th>
                            <th>Course Title</th>
                            <th>CV</th>
                            <th>CA Mark</th>
                            <th>Exam Mark</th>
                            <th>Final Mark</th>
                            <th>Grade</th>
                        </tr>
                    </thead>
                    <tbody class="text-center fs-vanis">
                        <?php if(count($courses) > 0): ?>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                            
                            <tr>
                                <td><?php echo e(++$id); ?></td>
                                <td><?php echo e($course->course_code); ?></td>
                                <td><?php echo e($course->course_title); ?></td>
                                <td><?php echo e($course->credit_value); ?></td>
                                <td><?php echo e($course->ca_mark); ?></td>
                                <td><?php echo e($course->exam_mark); ?></td>
                                <td><?php echo e($course->total_mark); ?></td>
                                <td><?php echo e($course->grade); ?></td>
                            </tr>
                    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?> 
                        <tr>
                            <td colspan="8" class="text-center fs-vanis">
                                No results available
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
               <?php if(count($courses) > 0): ?>
                <tfoot>
                    <div class="d-flex justify-content-between fw-bold text-capitalize">
                        <div>Attempted credits: <?php echo e($totalCredit); ?></div>
                        <div>Credits earned: <?php echo e($credit_earned); ?></div>
                        <div>GPA/4.0: <?php echo e($gpa); ?></div>
                    </div>
                </tfoot>
               <?php endif; ?>
            </div>
        </div>
        <!-- <div class="text-center fs-vanis">Total Credit: 40</div> -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NdeTek\Desktop\Vanis - Design\vanis - laravel\resources\views/result.blade.php ENDPATH**/ ?>