


<?php $__env->startSection('content'); ?>

  <!-- Nice courses bar -->
  <div class="container mt-5">
    <div class="row">
      <div class="col-lg-6 offset-lg-3">
        <div class="d-block d-flex justify-content-between bg-white rounded">
          <div class="text-center py-2 px-3 vanis-active">
            <a href="/course-registration/major" class="text-decoration-none text-dark fw-bold">Major</a>
          </div>
          <div class="text-center py-2 px-3">
            <a href="/course-registration/minor" class="text-decoration-none text-dark fw-bold">Minor</a>
          </div>
          <div class="text-center py-2 px-3">
            <a href="/course-registration/elective" class="text-decoration-none text-dark fw-bold">Elective</a>
          </div>
          <div class="text-center py-2 px-3">
            <a href="/course-registration/required" class="text-decoration-none text-dark fw-bold">Required</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <?php if($errors->has('reg_error')): ?>
  <div class="container mt-3">
    <div class="row">
      <div class="col-lg-6 offset-lg-3">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <strong>Error!</strong> No course has been added for registrtion.
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <?php if(session('success')): ?>
  <div class="container mt-3">
    <div class="row">
      <div class="col-lg-6 offset-lg-3">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong>Success!</strong> <?php echo e(session('success')); ?>.
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>
  <div class="center bg-primary" style="margin-top: 10px;">
    <div class="card w-75">
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-striped table-condensed">
            <thead class="text-primary text-center">
              <tr class="fs-vanis">
                <th>Course Code</th>
                <th>Course Title</th>
                <th>Credit Value</th>
                <th>Action</th>
              </tr>
              <tr>
                <th colspan="5" class="text-center bg-primary text-white border-0 text-capitalize">Semester courses</th>
              </tr>
            </thead>
            <tbody class="text-center fs-vanis">
              <?php if(count($courses) > 0): ?>
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($course->course_code); ?></td>
                  <td><?php echo e($course->course_title); ?></td>
                  <td><?php echo e($course->credit_value); ?></td>
                  <td>
                    <form action="<?php echo e(route('add-course')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">
                      <?php if(!in_array($course->id, $added_courses)): ?>
                        <button class="btn btn-outline-success btn-sm">
                          <i class="fas fa-plus"></i>
                          <span> Add</span>
                        </button>
                      <?php else: ?>
                        <button class="btn btn-outline-danger btn-sm">
                          <i class="fas fa-trash"></i>
                          <span> Remove</span>
                        </button>
                      <?php endif; ?>
                    </form>
                  </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
                <tr>
                  <td colspan="5" class="text-center fs-vanis text-capitalize">No courses found</td>
                </tr>
              <?php endif; ?>
              </tr>

              <tr>
                <td colspan="5" class="text-center bg-primary text-white border-0 text-capitalize">failed courses</td>
              </tr>
              <tr>
                <td colspan="5" class="text-center fs-vanis text-capitalize">No courses found</td>
              </tr>
              <!-- Loop courses here -->
              <tr>
                <td colspan="5" class="text-center bg-primary text-white border-0 text-capitalize">registered courses
                </td>
              </tr>
              <?php if(count($registered_courses) > 0): ?>
                <?php $__currentLoopData = $registered_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($course->course_code); ?></td>
                  <td><?php echo e($course->course_title); ?></td>
                  <td><?php echo e($course->credit_value); ?></td>
                  <td>
                    <form action="<?php echo e(route('drop-course')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">
                      <?php if(!in_array($course->id, $added_courses)): ?>
                        <button class="btn btn-outline-danger btn-sm">
                          <i class="fas fa-trash"></i>
                          <span> Drop</span>
                        </button>
                      <?php else: ?>
                        <button class="btn btn-outline-danger btn-sm">
                          <i class="fas fa-trash"></i>
                          <span> Remove</span>
                        </button>
                      <?php endif; ?>
                    </form>
                  </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
                <tr>
                  <td colspan="5" class="text-center fs-vanis text-capitalize">No courses found</td>
                </tr>
              <?php endif; ?>
            </tbody>
            <tfoot>
              <tr class="text-capitalize fs-vanis fw-bold">
                <td>Number of courses: <?php echo e($c_num); ?></td>
                <td colspan="4" class="text-end">Total credits: <?php echo e($c_credit); ?></td>
              </tr>
            </tfoot>
          </table>
          <div class="text-center">
            <form action="<?php echo e(route('register-courses')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <button class="btn btn-primary fs-vanis w-25">Done</button>
            </form>
          </div>
        </div>
      </div>
      <!-- <div class="text-center fs-vanis">Total Credit: 40</div> -->
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NdeTek\Desktop\Vanis - Design\vanis - laravel\resources\views/course-registration.blade.php ENDPATH**/ ?>