@extends('layouts.account')


@section('content')
<div class="center bg-primary">
    <div class="card w-75">
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-striped table-condensed">
            <thead class="text-primary text-center">
              <tr class="fs-vanis">
                <th>SN</th>
                <th>Course Code</th>
                <th>Course Title</th>
                <th>Credit Value</th>
              </tr>
            </thead>
            <tbody class="text-center fs-vanis">
              @if (count($courses) > 0)
              @foreach ($courses as $id => $course)
              <tr>
                <td>{{ ++$id }}</td>
                <td>{{ $course->course_code }}</td>
                <td>{{ $course->course_title }}</td>
                <td>{{ $course->credit_value }}</td>
              @endforeach
            @else
              <tr>
                <td colspan="5" class="text-center fs-vanis text-capitalize">No form B available</td>
              </tr>
            @endif
            </tbody>
          </table>
        </div>
      </div>
      <div class="text-center fs-vanis">Total Credit: {{ $credits }}</div>
    </div>
  </div>
@endsection