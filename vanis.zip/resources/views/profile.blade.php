@extends('layouts.account')


@section('content')
<div class="container" style="margin-top: 6rem">
    <div class="row">
        <div class="col-lg-4 offset-lg-4">
            <div class="card px-3">
                <div class="card-body fw-bold">
                    <h4 class="text-center fw-bold text-capitalize">{{ $user->name }}</h4>

                    <div class="d-flex justify-content-between text-capitalize fs-vanis">
                        <span>Matriculation number</span>
                        <span>level</span>
                    </div>
                    <div class="d-flex justify-content-between text-capitalize fs-6 mb-3">
                        <span>{{ $user->matricule }}</span>
                        <span>{{ $user->level }}</span>
                    </div>
                    <div class="d-flex justify-content-between text-capitalize fs-vanis">
                        <span>date of birth</span>
                        <span>sex</span>
                    </div>
                    <div class="d-flex justify-content-between text-capitalize fs-6 mb-3">
                        <span>{{ $user->date_of_birth }}</span>
                        <span>{{ $user->sex }}</span>
                    </div>
                    <div class="d-flex justify-content-between text-capitalize fs-vanis">
                        <span>faculty</span>
                        <span>department</span>
                    </div>
                    <div class="d-flex justify-content-between text-capitalize fs-6 mb-3">
                        <span>{{ $user->faculty }}</span>
                        <span>{{ $user->department }}</span>
                    </div>
                    <div class="d-flex justify-content-between text-capitalize fs-vanis">
                        <span>Degree programme</span>
                        <span>school fees</span>
                    </div>
                    <div class="d-flex justify-content-between text-capitalize fs-6 mb-3">
                        <span>{{ $user->degree_programme }}</span>
                        <span>{{ $user->school_fees }}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection