@extends('layouts.account')


@section('content')

<div class="container w-75 mt-5 text-white text-capitalize fs-vanis fw-bold">
    <form method="post" action="{{ route('get-result') }}">
        @csrf
        <div class="d-flex justify-content-between align-items-end">
                <div class="mb-3">
                    <label for="academic_year" class="form-label">Select academic year</label>
                    <select class="form-select" name="academic_year" id="academic_year" style="width: 250px;">
                        @foreach ($years as $year)
                            <option value="{{ $year }}" @selected($year == env('ACADEMIC_YEAR'))>{{ $year }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-3">
                    <label for="semester" class="form-label">Select semester</label>
                    <select class="form-select text-capitalize" name="semester" id="semester"  style="width: 250px;">
                        @foreach ($semesters as $sem)
                            <option value="{{ $sem }}" @selected($sem == env('SEMESTER'))>{{ $sem }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-success">Get Results</button>
                </div>
        </div>
    </form>
</div>

<div class="center bg-primary" style="margin-top: -200px;">
    <div class="card w-75">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-condensed">
                    <thead class="text-primary text-center">
                        <tr class="fs-vanis">
                            <th>SN</th>
                            <th>Course Code</th>
                            <th>Course Title</th>
                            <th>CV</th>
                            <th>CA Mark</th>
                            <th>Exam Mark</th>
                            <th>Final Mark</th>
                            <th>Grade</th>
                        </tr>
                    </thead>
                    <tbody class="text-center fs-vanis">
                        @if (count($courses) > 0)
                            @foreach ($courses as $id => $course)     
                            
                            <tr>
                                <td>{{ ++$id }}</td>
                                <td>{{ $course->course_code }}</td>
                                <td>{{ $course->course_title }}</td>
                                <td>{{ $course->credit_value }}</td>
                                <td>{{ $course->ca_mark }}</td>
                                <td>{{ $course->exam_mark }}</td>
                                <td>{{ $course->total_mark }}</td>
                                <td>{{ $course->grade }}</td>
                            </tr>
                    
                            @endforeach
                        @else 
                        <tr>
                            <td colspan="8" class="text-center fs-vanis">
                                No results available
                            </td>
                        </tr>
                        @endif
                    </tbody>
                </table>
               @if (count($courses) > 0)
                <tfoot>
                    <div class="d-flex justify-content-between fw-bold text-capitalize">
                        <div>Attempted credits: {{ $totalCredit }}</div>
                        <div>Credits earned: {{ $credit_earned }}</div>
                        <div>GPA/4.0: {{ $gpa }}</div>
                    </div>
                </tfoot>
               @endif
            </div>
        </div>
        <!-- <div class="text-center fs-vanis">Total Credit: 40</div> -->
    </div>
</div>
@endsection