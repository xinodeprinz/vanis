@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
      <div class="col-md-4 offset-md-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title text-center text-primary">CSC-Project</h5>
            <div class="card-subtitle mb-2 text-primary text-center fs-vanis">
              University of Buea
            </div>
            <div class="bg-primary text-white fs-vanis py-2 text-center text-uppercase m-0">
              sign in
            </div>
            <div class="text-center text-capitalize my-1 fw-bold fs-vanis">
              Login to your account
            </div>
            <form action="{{ route('login') }}" method="POST" class="mt-4">
              @csrf
              <div class="mb-3">
                <label for="matricule" class="form-label fs-vanis">Matriculation Number</label>
                <div class="input-group">
                  <span class="input-group-text bg-primary">
                    <i class="fas fa-user text-white"></i>
                  </span>
                  <input type="text" name="matricule" class="form-control border-primary @error('matricule')
                      is-invalid
                  @enderror" placeholder="Matricule" id="matricule" />
                  @error('matricule')
                      <div class="invalid-feedback">{{ $message }}</div>
                  @enderror
                </div>
              </div>
              <div class="mb-1">
                <label for="password" class="form-label fs-vanis">Password</label>
                <div class="input-group">
                  <span class="input-group-text bg-primary">
                    <i class="fas fa-lock text-white"></i>
                  </span>
                  <input type="password" name="password" placeholder="Password" class="form-control border-primary @error('password')
                      is-invalid
                  @enderror" id="password" />
                  @error('matricule')
                      <div class="invalid-feedback">{{ $message }}</div>
                  @enderror
                </div>
              </div>
              <a href="#" class="card-link mb-3 text-decoration-none fs-vanis fw-bold text-primary">Forgot Password?</a>
              <div class="mt-3">
                <button type="submit" class="btn btn-primary w-100 text-white text-capitalize fs-vanis">
                  Sign In
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection