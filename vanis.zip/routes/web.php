<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\DataController;
use App\Http\Controllers\FormBController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ResultController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::match(['GET', 'POST'], '/', [AuthController::class, 'login'])->name('login');
Route::get('/logout', [AuthController::class, 'logout'])->name('logout');
Route::get('/form-b', [FormBController::class, 'index']);
Route::get('/course-registration/{type}', [CourseController::class, 'index']);
Route::post('/register-courses', [CourseController::class, 'register'])->name('register-courses');
Route::post('/add-course', [CourseController::class, 'addCourse'])->name('add-course');
Route::post('/drop-course', [CourseController::class, 'dropCourse'])->name('drop-course');
Route::match(['GET', "POST"], '/result', [ResultController::class, 'index'])->name('get-result');
Route::get('/profile', [ProfileController::class, 'index'])->name('profile');

// Data routes
Route::get('/data/courses', [DataController::class, 'storeCourses']);


// Route::get('/hash', [AuthController::class, 'hashme']);